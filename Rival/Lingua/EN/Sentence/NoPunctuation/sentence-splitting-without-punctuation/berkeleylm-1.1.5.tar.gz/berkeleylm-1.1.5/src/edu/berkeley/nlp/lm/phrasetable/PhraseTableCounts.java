package edu.berkeley.nlp.lm.phrasetable;

public class PhraseTableCounts
{

	float[] features;

	public PhraseTableCounts(final float[] features) {
		this.features = features;
	}

}
