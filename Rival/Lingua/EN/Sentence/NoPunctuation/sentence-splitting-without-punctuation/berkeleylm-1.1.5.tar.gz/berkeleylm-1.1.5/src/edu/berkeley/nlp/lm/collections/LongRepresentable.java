package edu.berkeley.nlp.lm.collections;

public interface LongRepresentable<T> extends Comparable<T>
{

	public long asLong();

}
