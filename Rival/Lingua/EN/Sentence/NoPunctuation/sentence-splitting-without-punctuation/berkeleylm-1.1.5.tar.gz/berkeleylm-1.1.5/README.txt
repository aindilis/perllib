Berkeley Language Model release 1.0

To compile this software just type "ant" in the root directory (assuming ant is installed and properly configured).

For examples of command-line usage of this software for manipulating language model files, see the examples/ directory.

Please see javadoc in edu.berkeley.nlp.lm.io.LmReaders file for documentation.





